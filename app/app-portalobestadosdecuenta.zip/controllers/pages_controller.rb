class PagesController < ApplicationController
  def home
  end
  def facturas
  end
end
