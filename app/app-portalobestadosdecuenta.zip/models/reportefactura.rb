class Reportefactura < ActiveRecord::Base
end
