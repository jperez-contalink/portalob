class ReporteEstadoCuentum < ActiveRecord::Base
end
